package wildliferescuesystem;

public class OrphanedAnimalRescue extends RescueCase {

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(String rescueCaseID, String animalName,
                                String species, String rescueLocation,
                                String assignedRanger, int numberOfRescueDays,
                                double dailyCareCost, int estimatedAgeMonths,
                                double feedingCost,
                                boolean fosterCareRequired) {

        super(rescueCaseID, animalName, species, rescueLocation,
              assignedRanger, numberOfRescueDays, dailyCareCost);

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }

    @Override
    public double calculateTotalRescueCost() {
        double totalCost = calculateBaseCareCost() + feedingCost;

        if (fosterCareRequired) {
            totalCost += 2500;
        }

        return totalCost;
    }

    @Override
    public String determineRescuePriority() {
        if (estimatedAgeMonths <= 6) {
            return "High";
        } else if (fosterCareRequired) {
            return "High";
        } else {
            return "Normal";
        }
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    public String getSpecificInformation() {
        return "Estimated Age: " + estimatedAgeMonths + " months"
                + "\nFeeding Cost: R"
                + String.format("%.2f", feedingCost)
                + "\nFoster Care Required: "
                + (fosterCareRequired ? "Yes" : "No");
    }
} 