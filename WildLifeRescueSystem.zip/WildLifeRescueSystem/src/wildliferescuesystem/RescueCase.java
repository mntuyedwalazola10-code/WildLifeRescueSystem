package wildliferescuesystem;

/**
 * Abstract parent class containing information shared
 * by all wildlife rescue cases.
 */
public abstract class RescueCase implements RescueOperations {

    // Shared rescue case information
    private String rescueCaseID;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private String currentRescueStatus;

    // Constructor
    public RescueCase(String rescueCaseID, String animalName,
                      String species, String rescueLocation,
                      String assignedRanger, int numberOfRescueDays,
                      double dailyCareCost) {

        this.rescueCaseID = rescueCaseID;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;
        this.currentRescueStatus = "Pending";
    }

    // Get methods
    public String getRescueCaseID() {
        return rescueCaseID;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public String getCurrentRescueStatus() {
        return currentRescueStatus;
    }

    // Allows the rescue status to be updated
    public void setCurrentRescueStatus(String currentRescueStatus) {
        this.currentRescueStatus = currentRescueStatus;
    }

    // Common care cost for every rescue
    public double calculateBaseCareCost() {
        return numberOfRescueDays * dailyCareCost;
    }

    // Each rescue type calculates these differently
    public abstract double calculateTotalRescueCost();

    public abstract String determineRescuePriority();

    public abstract String getRescueType();

    // RescueOperations interface methods
    @Override
    public void startRescue() {
        currentRescueStatus = "Rescue in Progress";
    }

    @Override
    public void completeRescue() {
        currentRescueStatus = "Completed";
    }

    @Override
    public String generateRescueSummary() {
        return "Rescue Case ID: " + rescueCaseID
                + "\nRescue Type: " + getRescueType()
                + "\nSpecies: " + species
                + "\nAssigned Ranger: " + assignedRanger
                + "\nRescue Priority: " + determineRescuePriority()
                + "\nCurrent Status: " + currentRescueStatus
                + "\nTotal Rescue Cost: R"
                + String.format("%.2f", calculateTotalRescueCost());
    }
}