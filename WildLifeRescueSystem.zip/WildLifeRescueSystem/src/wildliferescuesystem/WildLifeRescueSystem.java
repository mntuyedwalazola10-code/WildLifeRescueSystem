package wildliferescuesystem;

import java.util.ArrayList;
import java.util.Scanner;

public class WildLifeRescueSystem {

    private static final ArrayList<RescueCase> rescueCases = new ArrayList<>();
    private static final Scanner input = new Scanner(System.in);

    public static void main(String[] args) {

        int option;

        do {
            displayMenu();
            option = readInteger("Select an option: ");

            switch (option) {

                case 1:
                    createRescueCase();
                    break;

                case 2:
                    searchRescueCase();
                    break;

                case 3:
                    updateRescueStatus();
                    break;

                case 4:
                    displayAllRescueCases();
                    break;

                case 5:
                    generateRescueReport();
                    break;

                case 6:
                    System.out.println(
                            "Exiting Wildlife Rescue Operations System...");
                    break;

                default:
                    System.out.println(
                            "Invalid option. Please select 1 to 6.");
            }

        } while (option != 6);
    }

    // Displays the main menu
    private static void displayMenu() {

        System.out.println("\n========================================");
        System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("========================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
        System.out.println("========================================");
    }

    // Reads a valid integer
    private static int readInteger(String message) {

        while (true) {

            try {
                System.out.print(message);
                return Integer.parseInt(input.nextLine());

            } catch (NumberFormatException e) {

                System.out.println(
                        "Invalid input. Please enter a number.");
            }
        }
    }

    // Reads a number greater than zero
    private static double readPositiveDouble(String message) {

        while (true) {

            try {
                System.out.print(message);

                double value =
                        Double.parseDouble(input.nextLine());

                if (value > 0) {
                    return value;
                }

                System.out.println(
                        "Value must be greater than zero.");

            } catch (NumberFormatException e) {

                System.out.println(
                        "Invalid input. Please enter a valid number.");
            }
        }
    }

    // Prevents required information from being blank
    private static String readRequiredString(String message) {

        while (true) {

            System.out.print(message);

            String value = input.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }

            System.out.println(
                    "This field cannot be blank.");
        }
    }

    // Validates Yes or No answers
    private static boolean readYesNo(String message) {

        while (true) {

            System.out.print(message);

            String answer = input.nextLine().trim();

            if (answer.equalsIgnoreCase("Y")
                    || answer.equalsIgnoreCase("Yes")) {

                return true;
            }

            if (answer.equalsIgnoreCase("N")
                    || answer.equalsIgnoreCase("No")) {

                return false;
            }

            System.out.println(
                    "Invalid input. Please enter Y or N.");
        }
    }

    // Searches for a rescue case using its ID
    public static RescueCase findRescueCase(String rescueCaseID) {

        for (RescueCase rescueCase : rescueCases) {

            if (rescueCase.getRescueCaseID()
                    .equalsIgnoreCase(rescueCaseID)) {

                return rescueCase;
            }
        }

        return null;
    }

    // Creates a new rescue case
    private static void createRescueCase() {

        System.out.println("\n--- CREATE RESCUE CASE ---");

        String rescueCaseID;

        while (true) {

            rescueCaseID =
                    readRequiredString("Enter Rescue Case ID: ");

            if (findRescueCase(rescueCaseID) == null) {
                break;
            }

            System.out.println(
                    "That Rescue Case ID already exists.");
            System.out.println(
                    "Please enter a unique Rescue Case ID.");
        }

        String animalName =
                readRequiredString("Enter Animal Name: ");

        String species =
                readRequiredString("Enter Species: ");

        String rescueLocation =
                readRequiredString("Enter Rescue Location: ");

        String assignedRanger =
                readRequiredString("Enter Assigned Ranger: ");

        int numberOfRescueDays;

        do {

            numberOfRescueDays =
                    readInteger("Enter Number of Rescue Days: ");

            if (numberOfRescueDays <= 0) {

                System.out.println(
                        "Rescue days must be greater than zero.");
            }

        } while (numberOfRescueDays <= 0);

        double dailyCareCost =
                readPositiveDouble(
                        "Enter Daily Care Cost: R");

        System.out.println("\nSelect Rescue Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");

        int rescueType;

        do {

            rescueType =
                    readInteger("Select rescue type (1-3): ");

            if (rescueType < 1 || rescueType > 3) {

                System.out.println(
                        "Please select 1, 2 or 3.");
            }

        } while (rescueType < 1 || rescueType > 3);

        RescueCase newCase;

        switch (rescueType) {

            case 1:

                String injuryDescription =
                        readRequiredString(
                                "Enter Injury Description: ");

                double veterinaryTreatmentCost =
                        readPositiveDouble(
                                "Enter Veterinary Treatment Cost: R");

                boolean surgeryRequired =
                        readYesNo(
                                "Is Surgery Required? (Y/N): ");

                newCase = new InjuredAnimalRescue(
                        rescueCaseID,
                        animalName,
                        species,
                        rescueLocation,
                        assignedRanger,
                        numberOfRescueDays,
                        dailyCareCost,
                        injuryDescription,
                        veterinaryTreatmentCost,
                        surgeryRequired
                );

                break;

            case 2:

                int estimatedAgeMonths;

                do {

                    estimatedAgeMonths =
                            readInteger(
                                    "Enter Estimated Age (Months): ");

                    if (estimatedAgeMonths <= 0) {

                        System.out.println(
                                "Age must be greater than zero.");
                    }

                } while (estimatedAgeMonths <= 0);

                double feedingCost =
                        readPositiveDouble(
                                "Enter Feeding Cost: R");

                boolean fosterCareRequired =
                        readYesNo(
                                "Is Foster Care Required? (Y/N): ");

                newCase = new OrphanedAnimalRescue(
                        rescueCaseID,
                        animalName,
                        species,
                        rescueLocation,
                        assignedRanger,
                        numberOfRescueDays,
                        dailyCareCost,
                        estimatedAgeMonths,
                        feedingCost,
                        fosterCareRequired
                );

                break;

            default:

                String conservationClassification =
                        readRequiredString(
                                "Enter Conservation Classification: ");

                double securityCost =
                        readPositiveDouble(
                                "Enter Security Cost: R");

                boolean specialistTeamRequired =
                        readYesNo(
                                "Is Specialist Team Required? (Y/N): ");

                newCase = new EndangeredSpeciesRescue(
                        rescueCaseID,
                        animalName,
                        species,
                        rescueLocation,
                        assignedRanger,
                        numberOfRescueDays,
                        dailyCareCost,
                        conservationClassification,
                        securityCost,
                        specialistTeamRequired
                );

                break;
        }

        rescueCases.add(newCase);

        System.out.println(
                "\nRescue case created successfully!");

        System.out.println(
                "Rescue Case ID: "
                        + newCase.getRescueCaseID());
    }

    // Searches for an existing rescue case
    private static void searchRescueCase() {

        System.out.println("\n--- SEARCH RESCUE CASE ---");

        String rescueCaseID =
                readRequiredString(
                        "Enter Rescue Case ID: ");

        RescueCase rescueCase =
                findRescueCase(rescueCaseID);

        if (rescueCase == null) {

            System.out.println(
                    "Rescue case not found.");

        } else {

            System.out.println();
            System.out.println(
                    rescueCase.generateRescueSummary());
        }
    }

    // Updates the rescue status
    private static void updateRescueStatus() {

        System.out.println(
                "\n--- UPDATE RESCUE STATUS ---");

        String rescueCaseID =
                readRequiredString(
                        "Enter Rescue Case ID: ");

        RescueCase rescueCase =
                findRescueCase(rescueCaseID);

        if (rescueCase == null) {

            System.out.println(
                    "Rescue case not found.");

            return;
        }

        System.out.println(
                "\nCurrent Status: "
                        + rescueCase.getCurrentRescueStatus());

        System.out.println("1. Start Rescue Operation");
        System.out.println("2. Complete Rescue Operation");

        int choice;

        do {

            choice =
                    readInteger("Select option (1-2): ");

            if (choice < 1 || choice > 2) {

                System.out.println(
                        "Please select 1 or 2.");
            }

        } while (choice < 1 || choice > 2);

        if (choice == 1) {

            rescueCase.startRescue();

            System.out.println(
                    "Rescue operation started successfully.");

        } else {

            rescueCase.completeRescue();

            System.out.println(
                    "Rescue operation completed successfully.");
        }

        System.out.println(
                "New Status: "
                        + rescueCase.getCurrentRescueStatus());
    }

    // Displays all rescue cases
    private static void displayAllRescueCases() {

        System.out.println(
                "\n--- ALL RESCUE CASES ---");

        if (rescueCases.isEmpty()) {

            System.out.println(
                    "No rescue cases are currently stored.");

            return;
        }

        for (RescueCase rescueCase : rescueCases) {

            System.out.println(
                    rescueCase.generateRescueSummary());

            System.out.println(
                    "Rescue Location: "
                            + rescueCase.getRescueLocation());

            System.out.println(
                    "----------------------------------------");
        }
    }

    // Generates the required rescue report
    private static void generateRescueReport() {

        System.out.println(
                "\n========================================");

        System.out.println(
                "WILDLIFE RESCUE REPORT");

        System.out.println(
                "========================================");

        if (rescueCases.isEmpty()) {

            System.out.println(
                    "No rescue cases are currently stored.");

            return;
        }

        double totalEstimatedCost = 0;

        for (RescueCase rescueCase : rescueCases) {

            System.out.println(
                    "Case ID          : "
                            + rescueCase.getRescueCaseID());

            System.out.println(
                    "Rescue Type      : "
                            + rescueCase.getRescueType());

            System.out.println(
                    "Species          : "
                            + rescueCase.getSpecies());

            System.out.println(
                    "Rescue Location  : "
                            + rescueCase.getRescueLocation());

            System.out.println(
                    "Assigned Ranger  : "
                            + rescueCase.getAssignedRanger());

            System.out.println(
                    "Rescue Priority  : "
                            + rescueCase.determineRescuePriority());

            System.out.println(
                    "Current Status   : "
                            + rescueCase.getCurrentRescueStatus());

            System.out.println(
                    "Total Rescue Cost: R"
                            + String.format(
                                    "%.2f",
                                    rescueCase.calculateTotalRescueCost()));

            System.out.println(
                    "----------------------------------------");

            totalEstimatedCost +=
                    rescueCase.calculateTotalRescueCost();
        }

        System.out.println(
                "Total Rescue Cases: "
                        + rescueCases.size());

        System.out.println(
                "Total Rescue Cost : R"
                        + String.format(
                                "%.2f",
                                totalEstimatedCost));

        System.out.println(
                "========================================");
    }
}