package wildliferescuesystem;

public class EndangeredSpeciesRescue extends RescueCase {

    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String rescueCaseID, String animalName,
                                   String species, String rescueLocation,
                                   String assignedRanger, int numberOfRescueDays,
                                   double dailyCareCost,
                                   String conservationClassification,
                                   double securityCost,
                                   boolean specialistTeamRequired) {

        super(rescueCaseID, animalName, species, rescueLocation,
              assignedRanger, numberOfRescueDays, dailyCareCost);

        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    public String getConservationClassification() {
        return conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }

    @Override
    public double calculateTotalRescueCost() {
        double totalCost = calculateBaseCareCost() + securityCost;

        if (specialistTeamRequired) {
            totalCost += 8000;
        }

        return totalCost;
    }

    @Override
    public String determineRescuePriority() {
        if (specialistTeamRequired) {
            return "Critical";
        } else if (conservationClassification.equalsIgnoreCase("Critically Endangered")) {
            return "Critical";
        } else {
            return "High";
        }
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    public String getSpecificInformation() {
        return "Conservation Classification: "
                + conservationClassification
                + "\nSecurity Cost: R"
                + String.format("%.2f", securityCost)
                + "\nSpecialist Team Required: "
                + (specialistTeamRequired ? "Yes" : "No");
    }
}