package wildliferescuesystem;

public class InjuredAnimalRescue extends RescueCase {

    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(String rescueCaseID, String animalName,
                               String species, String rescueLocation,
                               String assignedRanger, int numberOfRescueDays,
                               double dailyCareCost, String injuryDescription,
                               double veterinaryTreatmentCost,
                               boolean surgeryRequired) {

        super(rescueCaseID, animalName, species, rescueLocation,
              assignedRanger, numberOfRescueDays, dailyCareCost);

        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    public String getInjuryDescription() {
        return injuryDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }

    @Override
    public double calculateTotalRescueCost() {
        double totalCost = calculateBaseCareCost()
                + veterinaryTreatmentCost;

        if (surgeryRequired) {
            totalCost += 5000;
        }

        return totalCost;
    }

    @Override
    public String determineRescuePriority() {
        if (surgeryRequired) {
            return "Critical";
        } else if (veterinaryTreatmentCost > 3000) {
            return "High";
        } else {
            return "Normal";
        }
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    public String getSpecificInformation() {
        return "Injury Description: " + injuryDescription
                + "\nVeterinary Treatment Cost: R"
                + String.format("%.2f", veterinaryTreatmentCost)
                + "\nSurgery Required: "
                + (surgeryRequired ? "Yes" : "No");
    }
}