package wildliferescuesystem;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class RescueCaseTest {

    private RescueCase rescueCase;

    /*
     * RescueCase is abstract, so this small class allows us
     * to create an object for testing the parent class.
     */
    private static class TestRescueCase extends RescueCase {

        public TestRescueCase(String rescueCaseID,
                              String animalName,
                              String species,
                              String rescueLocation,
                              String assignedRanger,
                              int numberOfRescueDays,
                              double dailyCareCost) {

            super(rescueCaseID, animalName, species,
                  rescueLocation, assignedRanger,
                  numberOfRescueDays, dailyCareCost);
        }

        @Override
        public double calculateTotalRescueCost() {
            return calculateBaseCareCost();
        }

        @Override
        public String determineRescuePriority() {
            return "Normal";
        }

        @Override
        public String getRescueType() {
            return "Test Rescue";
        }
    }

    @Before
    public void setUp() {

        rescueCase = new TestRescueCase(
                "RC001",
                "Simba",
                "Lion",
                "Cape Town",
                "Ranger John",
                5,
                200.00
        );
    }

    @Test
    public void testGetRescueCaseID() {
        assertEquals(
                "RC001",
                rescueCase.getRescueCaseID()
        );
    }

    @Test
    public void testGetAnimalName() {
        assertEquals(
                "Simba",
                rescueCase.getAnimalName()
        );
    }

    @Test
    public void testGetSpecies() {
        assertEquals(
                "Lion",
                rescueCase.getSpecies()
        );
    }

    @Test
    public void testGetRescueLocation() {
        assertEquals(
                "Cape Town",
                rescueCase.getRescueLocation()
        );
    }

    @Test
    public void testGetAssignedRanger() {
        assertEquals(
                "Ranger John",
                rescueCase.getAssignedRanger()
        );
    }

    @Test
    public void testGetNumberOfRescueDays() {
        assertEquals(
                5,
                rescueCase.getNumberOfRescueDays()
        );
    }

    @Test
    public void testGetDailyCareCost() {
        assertEquals(
                200.00,
                rescueCase.getDailyCareCost(),
                0.01
        );
    }

    @Test
    public void testInitialRescueStatus() {
        assertEquals(
                "Pending",
                rescueCase.getCurrentRescueStatus()
        );
    }

    @Test
    public void testCalculateBaseCareCost() {
        assertEquals(
                1000.00,
                rescueCase.calculateBaseCareCost(),
                0.01
        );
    }

    @Test
    public void testCalculateTotalRescueCost() {
        assertEquals(
                1000.00,
                rescueCase.calculateTotalRescueCost(),
                0.01
        );
    }

    @Test
    public void testDetermineRescuePriority() {
        assertEquals(
                "Normal",
                rescueCase.determineRescuePriority()
        );
    }

    @Test
    public void testGetRescueType() {
        assertEquals(
                "Test Rescue",
                rescueCase.getRescueType()
        );
    }

    @Test
    public void testSetCurrentRescueStatus() {

        rescueCase.setCurrentRescueStatus("On Hold");

        assertEquals(
                "On Hold",
                rescueCase.getCurrentRescueStatus()
        );
    }

    @Test
    public void testStartRescue() {

        rescueCase.startRescue();

        assertEquals(
                "Rescue in Progress",
                rescueCase.getCurrentRescueStatus()
        );
    }

    @Test
    public void testCompleteRescue() {

        rescueCase.completeRescue();

        assertEquals(
                "Completed",
                rescueCase.getCurrentRescueStatus()
        );
    }

    @Test
    public void testGenerateRescueSummary() {

        String summary = rescueCase.generateRescueSummary();

        assertTrue(summary.contains("RC001"));
        assertTrue(summary.contains("Test Rescue"));
        assertTrue(summary.contains("Lion"));
        assertTrue(summary.contains("Ranger John"));
        assertTrue(summary.contains("Normal"));
        assertTrue(summary.contains("Pending"));
        assertTrue(summary.contains("1000.00"));
    }
}